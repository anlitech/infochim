# Epic BG PPSSPP like

Responsive background for website or NWJS/Electron app, written with pure CSS3.<br>
As seen in PPSSPP.<br>
Icons editor is attached (with FontAwesome icons pack), so it is very easy to customize every icon and the overall result.<br>

![demo screenshot](screenshot.jpg)

# Demo
PPSSPP icons - https://priler.github.io/Epic-BG-PPSSPP-like-/ppsspp.html<br>
Custom icons - https://priler.github.io/Epic-BG-PPSSPP-like-/index.html<br>
Editor - https://priler.github.io/Epic-BG-PPSSPP-like-/edit.html<br>

### Author

Abraham Tugalov (a.k.a. Priler)

License
----

MIT


**Free Software, Hell Yeah!**
